from django.contrib import admin
from appMesaServicio.models import OficinaAmbiente, User, TipoProcedimiento

# Register your models here.

admin.site.register(OficinaAmbiente)
admin.site.register(User)
admin.site.register(TipoProcedimiento)
